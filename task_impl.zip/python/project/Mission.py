import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
from interface.Task import TaskArguments, TaskType


class Mission:

    # transition
    @staticmethod
    def start_transit(triggered_event):
        logger.info("start_transit\n")
        return "tri"
    @staticmethod
    def rect_transit(triggered_event):
        if (triggered_event == "done"):
            return "tri"
    @staticmethod
    def tri_transit(triggered_event):
        if (triggered_event == "timeout"):
            return "rect"
        if (triggered_event == "done"):
            return "terminate"

    @staticmethod
    def default_transit(triggered_event):
        logger.info(f"no matched up transition, triggered event {triggered_event}\n", triggered_event)
    #task
    @staticmethod
    def define_mission(transitMap, task_arg_map):
        #define transition
        logger.info("define the transitMap\n")
        transitMap["start"] = Mission.start_transit
        transitMap["rect"]= Mission.rect_transit
        transitMap["tri"]= Mission.tri_transit
        transitMap["default"]= Mission.default_transit
        # define task
        logger.info("define the tasks\n")
        # TASKrect
        task_attr_rect = {}
        task_attr_rect["gimbal_pitch"] = "-20.0"
        task_attr_rect["drone_rotation"] = "0.0"
        task_attr_rect["sample_rate"] = "2"
        task_attr_rect["hover_delay"] = "0"
        task_attr_rect["coords"] = "Rectangle"
        task_attr_rect["model"] = "coco"
        task_attr_rect["upper_bound"] = [50, 255, 255]
        task_attr_rect["lower_bound"] = [30, 100, 100]
        transition_attr_rect = {}
        task_arg_map["rect"] = TaskArguments(TaskType.Detect, transition_attr_rect, task_attr_rect)
        # TASKtri
        task_attr_tri = {}
        task_attr_tri["gimbal_pitch"] = "-20.0"
        task_attr_tri["drone_rotation"] = "0.0"
        task_attr_tri["sample_rate"] = "2"
        task_attr_tri["hover_delay"] = "0"
        task_attr_tri["coords"] = "Triangle"
        task_attr_tri["model"] = "coco"
        task_attr_tri["upper_bound"] = [50, 255, 255]
        task_attr_tri["lower_bound"] = [30, 100, 100]
        transition_attr_tri = {}
        transition_attr_tri["timeout"] = 10.0
        task_arg_map["tri"] = TaskArguments(TaskType.Detect, transition_attr_tri, task_attr_tri)
        logger.info("finish defining the tasks\n")
